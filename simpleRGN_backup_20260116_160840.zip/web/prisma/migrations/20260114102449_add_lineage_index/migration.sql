-- AlterTable
ALTER TABLE "Participation" ADD COLUMN     "lineageIndex" TEXT;
