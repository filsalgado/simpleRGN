-- AlterTable
ALTER TABLE "User" ADD COLUMN     "currentEventType" TEXT;
