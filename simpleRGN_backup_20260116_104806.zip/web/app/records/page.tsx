'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';

type RecordSummary = {
    id: string;
    type: 'BAPTISM' | 'MARRIAGE' | 'DEATH';
    date: string;
    parish: string;
    mainName: string;
    createdAt: string;
};

export default function RecordsListPage() {
    const [records, setRecords] = useState<RecordSummary[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [page, setPage] = useState(1);
    const [totalPages, setTotalPages] = useState(1);

    const fetchRecords = async (pageNum: number) => {
        setIsLoading(true);
        try {
            const res = await fetch(`/api/records?page=${pageNum}&limit=10`);
            const data = await res.json();
            if (data.data) {
                setRecords(data.data);
                setTotalPages(data.meta.totalPages);
            }
        } catch (error) {
            console.error("Failed to load records", error);
        } finally {
            setIsLoading(false);
        }
    };

    useEffect(() => {
        fetchRecords(page);
    }, [page]);

    const getTypeLabel = (type: string) => {
        switch (type) {
            case 'BAPTISM': return <span className="badge bg-info text-white">Batismo</span>;
            case 'MARRIAGE': return <span className="badge bg-secondary text-white">Casamento</span>;
            case 'DEATH': return <span className="badge bg-dark text-white">Óbito</span>;
            default: return type;
        }
    };

    return (
        <div className="container py-4">
            <div className="card mb-4 border-0 shadow-sm">
                <div className="card-body">
                    <div className="d-flex justify-content-between align-items-center">
                        <div>
                            <h1 className="h4 mb-1 fw-bold">Registos Paroquiais</h1>
                            <p className="text-muted small mb-0">Listagem de assentos da paróquia ativa</p>
                        </div>
                        <Link href="/records/new" className="btn btn-primary">
                            + Novo Registo
                        </Link>
                    </div>
                </div>
            </div>

            <div className="card border-0 shadow-sm">
                <div className="card-body">
                    {isLoading ? (
                        <div className="text-center py-5">
                            <div className="spinner-border text-primary mb-2" role="status">
                                <span className="visually-hidden">A carregar...</span>
                            </div>
                            <p className="text-muted">A carregar registos...</p>
                        </div>
                    ) : records.length === 0 ? (
                        <div className="text-center py-5">
                            <p className="text-muted">Não existem registos nesta paróquia.</p>
                            <Link href="/records/new" className="btn btn-link">
                                Criar o primeiro registo
                            </Link>
                        </div>
                    ) : (
                        <div className="table-responsive">
                            <table className="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Assento</th>
                                        <th>Tipo</th>
                                        <th>Data</th>
                                        <th>Paróquia</th>
                                        <th>Ações</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {records.map((record) => (
                                        <tr key={record.id}>
                                            <td className="fw-semibold">{record.mainName}</td>
                                            <td>{getTypeLabel(record.type)}</td>
                                            <td>{record.date}</td>
                                            <td className="text-muted">{record.parish}</td>
                                            <td>
                                                <Link href={`/records/${record.id}`} className="btn btn-sm btn-outline-primary">
                                                    Ver Detalhes
                                                </Link>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    )}
                    
                    {!isLoading && records.length > 0 && (
                        <div className="d-flex justify-content-between align-items-center mt-3 pt-3 border-top">
                            <small className="text-muted">Página {page} de {totalPages}</small>
                            <div className="btn-group" role="group">
                                <button 
                                    onClick={() => setPage(p => Math.max(1, p - 1))}
                                    disabled={page === 1}
                                    className="btn btn-sm btn-outline-secondary"
                                >
                                    &larr; Anterior
                                </button>
                                <button 
                                    onClick={() => setPage(p => Math.min(totalPages, p + 1))}
                                    disabled={page === totalPages}
                                    className="btn btn-sm btn-outline-secondary"
                                >
                                    Seguinte &rarr;
                                </button>
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}
