Necessito de fazer algumas alterações na app. 

É necessário de registar o Estado Civil dos intervenientes nos eventos ( dropdown com as opções Solteiro(a), Casado(a), Viúvo(a), Separado(a), Divorciado(a) alimentada por nova tabela na bd). Aqui consideramos que todos os participantes (batizando, noivo, pais, padrinhos, testemunhas,... ) podem ter a indicação do estado civil no momento da realização daquele ato e por isso, deve existir a posibilidade de registo dessa informação em cada um deles.
Pdes implementar as alterações necessárias?
